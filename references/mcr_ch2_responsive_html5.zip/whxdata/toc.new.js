(function() {
var toc =  [{"key":"toc1","name":"MICHIGAN COURT RULES OF 1985","type":"book","url":"Court_Rules_Book_Ch_2/Court_Rules_Chapter_2/Court_Rules_Chapter_2.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();