# VISUAL_PROOF_INDEX

| Proof Step | Evidence Pointer | Reference |
|---|---|---|
| withheld | auditEventId: `cmkszejz7000rcrrs6e6p5n3b` | audit_withheld_excerpt.json (row id matches) |
| teleport | proof.pdf page 1 (anchor agreement) | artifacts/outputs/proof.pdf |
| export | packet contents manifest | manifest.json + hashes.txt |
