# Initial Tech Meeting Demo Script (8-12 minutes)

Audience: LexisNexis technical + product + compliance.
Goal: Prove deterministic guardrails, anchored evidence, integrity ledger, and audit trail with live UI and API proofs.

## 0. Setup (0:00-0:30)
- Click: Open the app, land on Dashboard.
- Say: "This is LexiPro running as a Shadow DOM component, so it can drop into a Lexis portal without CSS/JS collisions. Today I will prove anchors, guardrails, integrity, and audit in under 10 minutes."

## 1. Evidence ingest + hash chain (0:30-2:00)
- Click: Sidebar -> Exhibit Manager -> Upload Exhibit (select a PDF).
- Say: "Upload triggers immediate SHA-256 hashing and writes the first chain-of-custody entry. This hash is the anchor for all later claims."
- Endpoint to show: `GET /api/integrity/verify` (Integrity ledger check).
- Say: "This returns the ledger verification result and the latest integrity hash, so we can prove the chain is intact on demand."

## 2. Anchors + viewer highlights (2:00-3:30)
- Click: Exhibit Manager -> Open the exhibit -> View anchors/highlights.
- Say: "Anchors are stored with page and bounding box coordinates, so every claim can teleport to its source line."
- Endpoint to show: `GET /api/workspaces/:workspaceId/exhibits/:exhibitId/anchors`.
- Say: "This is the anchor table. The UI renders these coordinates as highlights."

## 3. Guardrails proof (3:30-4:30)
- Endpoint to show: `GET /api/ai/guardrails`.
- Say: "This returns the enforced temperature, prompt policy, anchorsRequired flag, and release gate policy. It is not a promise; it is the contract the server enforces."

## Phase 3.5: The Assumptive Close
Context: "Now, let's verify the contents of the deal on the table."

Action: Open "Exhibit A: Executed Letter of Intent".

Action: Point out the "$55,000,000" figure in the PDF viewer.

Action: Open the Forensic AI Assistant.

Prompt: "What is the total proposed purchase price and is it contingent on anything?"

The Result:
- Watch the AI verify the optical coordinates of "$55,000,000".
- Say: "The AI isn't hallucinating this number. It is reading the pixel coordinates from the offer you just sent us. It validates the technical diligence clause automatically."

Closing Line:
- Say: "The system has verified your offer. The only question left is: when do we sign?"

## 4. AI request with release gate (4:30-6:30)
- Click: Open the AI analysis panel (use a grounded workflow like chat or timeline).
- Say: "The backend only emits claims that already map to anchors in the database. Anything unanchored is blocked before the UI can render it."
- Endpoint to show (optional): `POST /api/ai/chat` with anchor-backed request.
- Say: "Every claim returns with anchorId, page, and bbox so we can prove its source."

## 5. 422 demonstration (6:30-7:30)
- Endpoint to show: `POST /api/ai/chat` with missing/invalid anchors.
- Say: "No Anchor -> No Output. The server returns 422 and logs the rejection. That is the release gate working."
- Click: Sidebar -> Integrity Audit -> Audit log.
- Say: "You can see the blocked attempt recorded as an audit event."

## 6. Teleport proof (7:30-8:30)
- Click: In the AI result, click a citation.
- Say: "Teleport jumps to the exact coordinates in the PDF. This is the strongest, visual proof of grounded output."

## 7. ROI + exportable proof (8:30-10:00)
- Endpoint to show: `GET /api/workspaces/:workspaceId/misconduct/analyze`.
- Say: "This endpoint calculates settlement gap value and automation rate from anchored facts, so ROI is traceable back to evidence."
- Endpoint to show: `POST /api/workspaces/:workspaceId/audit/generate-report`.
- Say: "This generates the integrity certificate PDF with embedded hashes for diligence and audit teams."

## Fallbacks if the AI model is unavailable
- Use `GET /api/ai/guardrails` to prove guardrails are enforced server-side.
- Use `GET /api/workspaces/:workspaceId/audit/logs` to show prior AI audit entries and 422 blocks.
- Use `GET /api/workspaces/:workspaceId/exhibits/:exhibitId/anchors` to show anchor table and drive teleport manually.
- Show Integrity Audit module to prove verify-on-read and ledger status without AI output.

## Wow moments to highlight
- Ledger verified live: `GET /api/integrity/verify`.
- Anchors render as pixel-perfect highlights.
- Click citation -> teleport to source line.
- Release gate 422 prevents any ungrounded claim.
- Integrity certificate PDF for auditors.
- Automated settlement discovery from anchored facts.

---

## Phase 5: The Sabotage (The "Mic Drop")
Context: "You might ask: What if a rogue admin tries to alter the history?"

### 1. The Attack
Action: Open your terminal.

Command: Run this SQL to delete the most recent audit event:
```bash
# (Simulated Attack)
sqlite3 server/dev.db "DELETE FROM AuditEvent WHERE id = (SELECT id FROM AuditEvent ORDER BY createdAt DESC LIMIT 1);"
```
Note: If using Postgres, adjust the command accordingly, or just say "I am simulating a DB deletion now".

### 2. The Detection
Action: Refresh the Integrity Audit dashboard.

Expectation: The status badge should turn RED.

UI: "TAMPER DETECTED: Hash Mismatch at Block [N]."

### 3. The Recovery
Say: "The database is broken, but the evidence is safe. Because of Immutable Log Shipping, I can rebuild the legal truth from the S3 'Black Box' right now."

### 4. The Close
Say: "This is why you buy LexiPro. We assume the environment is hostile. Your internal tools assume it's safe."
