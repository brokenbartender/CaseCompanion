# npm audit summary

## Root
- total: 0 (low: 0, moderate: 0, high: 0, critical: 0)

## Server
- total: 1 (low: 1, moderate: 0, high: 0, critical: 0)
- vuln: diff (low) � jsdiff has a Denial of Service vulnerability in parsePatch and applyPatch
- advisory: https://github.com/advisories/GHSA-73rr-hh4g-fpgx
- status: transitive dependency (not direct)
- plan: accept for demo; upgrade when upstream dependency bumps diff >= 4.0.4
