# M&A Green Run Results

status: PASS

outputs: reports/mna/20260123-1700/outputs
commands: reports/mna/20260123-1700/commands.txt
versions: reports/mna/20260123-1700/versions.txt
